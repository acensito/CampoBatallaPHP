<!DOCTYPE html>
<!-- Desarrollo Web en Entorno Servidor -->
<!-- Tema 04  -->
<!-- Probando Smarty-->
<html>
    
<head>
    <meta charset="utf-8">
    <title>DWES - CampoBatallaPHP</title>
    <!--<link type="text/css" href="estilos.css" rel="stylesheet" />-->
</head>

<body>
    <h1 class="centrado">Ejemplo Tema 4</h1>
    <h2 class="centrado">CampoBatallaPHP</h2>
    
    <p>Esto es un parrafo normal y corriente</p>
    
    <footer>Felipe Rodriguez Gutiérrez - DWES - Curso 2016/2017</footer>
</body>
</html>